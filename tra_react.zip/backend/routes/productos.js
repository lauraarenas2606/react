const express = require('express');
const router = express.Router();
const productosController = require('../controllers/productosController');

// Rutas para productos
router.get('/productos', productosController.getProductos);
router.post('/productos', productosController.createProducto);
router.get('/productos/:id', productosController.getProductoById);
router.put('/productos/:id', productosController.updateProducto);
router.delete('/productos/:id', productosController.deleteProducto);

// Ruta para decrementar la cantidad de un producto
router.put('/productos/decrementar/:id', productosController.decrementarCantidad);

module.exports = router;
