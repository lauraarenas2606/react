const express = require('express');
const router = express.Router();
const formularioController = require('../controllers/formularioController');

// Rutas para formularios
router.get('/', formularioController.getFormularios);
router.post('/', formularioController.createFormulario);
router.get('/:id', formularioController.getFormularioById);
router.put('/:id', formularioController.updateFormulario);
router.delete('/:id', formularioController.deleteFormulario);

module.exports = router;
