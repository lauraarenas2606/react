const Formulario = require('../models/formulario');

// Obtener todos los formularios
exports.getFormularios = async (req, res) => {
    try {
        const formularios = await Formulario.find();
        res.status(200).json(formularios);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener los formularios' });
    }
};

// Crear un nuevo formulario
exports.createFormulario = async (req, res) => {
    try {
        const { nombre, email, mensaje } = req.body;
        if (!nombre || !email || !mensaje) {
            return res.status(400).json({ error: 'Faltan campos requeridos' });
        }
        const formulario = new Formulario({ nombre, email, mensaje });
        await formulario.save();
        res.status(201).json(formulario);
    } catch (error) {
        res.status(500).json({ error: 'Error al guardar el formulario' });
    }
};

// Obtener un formulario por su ID
exports.getFormularioById = async (req, res) => {
    try {
        const formulario = await Formulario.findById(req.params.id);
        if (!formulario) {
            return res.status(404).json({ error: 'Formulario no encontrado' });
        }
        res.status(200).json(formulario);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener el formulario' });
    }
};

// Actualizar un formulario
exports.updateFormulario = async (req, res) => {
    try {
        const formulario = await Formulario.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!formulario) {
            return res.status(404).json({ error: 'Formulario no encontrado' });
        }
        res.status(200).json(formulario);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el formulario' });
    }
};

// Eliminar un formulario
exports.deleteFormulario = async (req, res) => {
    try {
        const formulario = await Formulario.findByIdAndDelete(req.params.id);
        if (!formulario) {
            return res.status(404).json({ error: 'Formulario no encontrado' });
        }
        res.status(200).json({ message: 'Formulario eliminado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar el formulario' });
    }
};
