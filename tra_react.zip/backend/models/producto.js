const mongoose = require('mongoose');

const productoSchema = new mongoose.Schema({
    nombre: { type: String, required: true },
    precio: { type: Number, required: true },
    descripcion: { type: String, required: true },
    cantidad: { type: Number, required: true, default: 0 }, // Asegúrate de tener la cantidad
}, {
    timestamps: true
});

module.exports = mongoose.model('Producto', productoSchema);
