import React from 'react';
import './Footer.css'; // Importa un archivo CSS externo

function Footer() {
    return (
        <footer className="footer">
            <div className="footer__contenedor">
                <p>&copy; {new Date().getFullYear()} Mi Tienda. Todos los derechos reservados.</p>
                {/* Puedes agregar más información en el footer, como enlaces a redes sociales */}
            </div>
        </footer>
    );
}

export default Footer;
