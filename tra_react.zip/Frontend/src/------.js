import React, { useState } from 'react';
import axios from 'axios';

function Formulario({ productoId }) {
    const [nombre, setNombre] = useState('');
    const [email, setEmail] = useState('');
    const [mensaje, setMensaje] = useState('');
    const [successMessage, setSuccessMessage] = useState(''); // Nuevo estado para el mensaje de éxito

    const handleSubmit = async (event) => {
        event.preventDefault(); // Evita que la página se recargue

        try {
            await axios.post('http://3.84.108.84:5000/api/formulario', {
                nombre,
                email,
                mensaje,
                productoId, // Agrega el ID del producto al formulario
            });
            // Limpia el formulario después de enviar
            setNombre('');
            setEmail('');
            setMensaje('');
            // Muestra un mensaje de éxito al usuario
            setSuccessMessage('Formulario enviado con éxito');
            // Limpia el mensaje de éxito después de 3 segundos
            setTimeout(() => {
                setSuccessMessage('');
            }, 3000);
        } catch (error) {
            console.error('Error al enviar el formulario:', error);
            // Puedes mostrar un mensaje de error al usuario aquí
        }
    };

    // Estilos CSS en línea
    const formStyles = {
        width: '100%',
        maxWidth: '600px', // Se ajusta automáticamente al tamaño de pantalla
        margin: '20px auto',
        padding: '20px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
        fontFamily: 'Arial, sans-serif',
    };

    const headingStyles = {
        textAlign: 'center',
        marginBottom: '20px',
        fontSize: '1.5rem',
        color: '#2c3e50',
    };

    const inputStyles = {
        width: '100%',
        padding: '12px',
        fontSize: '1rem',
        border: '1px solid #ccc',
        borderRadius: '5px',
        boxSizing: 'border-box',
        marginTop: '5px',
    };

    const buttonStyles = {
        width: '100%',
        padding: '15px',
        backgroundColor: '#3498db',
        color: 'white',
        fontSize: '1rem',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
        transition: 'background-color 0.3s ease',
    };

    const buttonHoverStyles = {
        backgroundColor: '#2980b9',
    };

    const buttonActiveStyles = {
        backgroundColor: '#1c5981',
    };

    // Estilos responsivos con media query
    const mediaQueryStyles = `
        @media (max-width: 768px) {
            ${JSON.stringify(formStyles)}
            padding: 15px;
            max-width: 90%;
            margin: 15px auto;
        }
        @media (max-width: 480px) {
            ${JSON.stringify(formStyles)}
            max-width: 100%;
            padding: 10px;
            margin: 10px;
        }
    `;

    return (
        <>
            <style>
                {mediaQueryStyles}
            </style>
            <form onSubmit={handleSubmit} style={formStyles}>
                <h3 style={headingStyles}>Deja tu comentario</h3>
                <div>
                    <label htmlFor="nombre">Nombre:</label>
                    <input
                        type="text"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        required
                        style={inputStyles}
                    />
                </div>
                <div>
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        style={inputStyles}
                    />
                </div>
                <div>
                    <label htmlFor="mensaje">Mensaje:</label>
                    <textarea
                        id="mensaje"
                        value={mensaje}
                        onChange={(e) => setMensaje(e.target.value)}
                        required
                        style={inputStyles}
                    />
                </div>
                <button
                    type="submit"
                    style={buttonStyles}
                    onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyles.backgroundColor)}
                    onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyles.backgroundColor)}
                    onMouseDown={(e) => (e.target.style.backgroundColor = buttonActiveStyles.backgroundColor)}
                    onMouseUp={(e) => (e.target.style.backgroundColor = buttonHoverStyles.backgroundColor)}
                >
                    Enviar
                </button>
                {successMessage && (
                    <div
                        style={{
                            marginTop: '20px',
                            padding: '10px',
                            backgroundColor: '#2ecc71',
                            color: 'white',
                            textAlign: 'center',
                            borderRadius: '5px',
                        }}
                    >
                        {successMessage}
                    </div>
                )}
            </form>
        </>
    );
}

export default Formulario;
