import React, { useState } from 'react';
import Navbar from './Navbar';
import ProductList from './ProductList';
import ListaMensajes from './ListaMensajes';
import Footer from './Footer'; // Importa el Footer
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [carrito, setCarrito] = useState([]);  // Estado para almacenar los productos en el carrito
  const [isModalOpen, setIsModalOpen] = useState(false);  // Estado para manejar la apertura/cierre del modal

  // Función para agregar un producto al carrito
  const agregarAlCarrito = (producto) => {
    setCarrito((prevCarrito) => {
      const existeProducto = prevCarrito.find((item) => item._id === producto._id);
      if (existeProducto) {
        // Si el producto ya existe en el carrito, solo incrementa la cantidad
        return prevCarrito.map((item) =>
          item._id === producto._id
            ? { ...item, cantidad: item.cantidad + 1 }  // Incrementa la cantidad
            : item
        );
      } else {
        // Si el producto no existe, lo agrega con cantidad 1
        return [...prevCarrito, { ...producto, cantidad: 1 }];
      }
    });
  };

  // Función para incrementar la cantidad de un producto en el carrito
  const incrementarCantidad = (productoId) => {
    setCarrito((prevCarrito) =>
      prevCarrito.map((item) =>
        item._id === productoId ? { ...item, cantidad: item.cantidad + 1 } : item
      )
    );
  };

  // Función para decrementar la cantidad de un producto en el carrito
  const decrementarCantidad = (productoId) => {
    setCarrito((prevCarrito) =>
      prevCarrito.map((item) =>
        item._id === productoId && item.cantidad > 1
          ? { ...item, cantidad: item.cantidad - 1 }  // Decrementa la cantidad si es mayor que 1
          : item
      )
    );
  };

  // Función para eliminar un producto del carrito
  const eliminarProducto = (productoId) => {
    setCarrito((prevCarrito) => prevCarrito.filter((item) => item._id !== productoId));
  };

  // Función para abrir el modal
  const abrirModal = () => {
    setIsModalOpen(true);
  };

  // Función para cerrar el modal
  const cerrarModal = () => {
    setIsModalOpen(false);
  };

  // Calcular el total de los productos en el carrito con 2 decimales
  const calcularTotal = () => {
    return carrito.reduce((total, producto) => total + producto.precio * producto.cantidad, 0).toFixed(2);
  };

  // Formatear el precio de cada producto para mostrarlo con 2 decimales
  const formatearPrecio = (precio) => {
    return precio.toFixed(2);
  };

  return (
    <div>
      <Navbar carrito={carrito.length} abrirModal={abrirModal} />
      <ProductList carrito={carrito} agregarAlCarrito={agregarAlCarrito} />
      <ListaMensajes />

      {/* Modal para mostrar el carrito */}
      {isModalOpen && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1" role="dialog" aria-labelledby="modalCarritoLabel" aria-hidden="true">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="modalCarritoLabel">Productos en el Carrito</h5>
                <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={cerrarModal}>
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {carrito.length === 0 ? (
                  <p>No hay productos en el carrito.</p>
                ) : (
                  <ul className="list-group">
                    {carrito.map((producto) => (
                      <li className="list-group-item d-flex justify-content-between align-items-center" key={producto._id}>
                        <img src={producto.imagen || 'https://via.placeholder.com/150'} alt={producto.nombre} className="img-thumbnail" style={{ width: '50px', height: '50px' }} />
                        <span>{producto.nombre} - ${formatearPrecio(producto.precio)}</span>
                        <div className="d-flex align-items-center">
                          <button className="btn btn-sm btn-outline-secondary" onClick={() => decrementarCantidad(producto._id)}>-</button>
                          <span className="mx-2">{producto.cantidad}</span>
                          <button className="btn btn-sm btn-outline-secondary" onClick={() => incrementarCantidad(producto._id)}>+</button>
                          <button className="btn btn-sm btn-danger ms-2" onClick={() => eliminarProducto(producto._id)}>Eliminar</button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
                <hr />
                <h6>Total: ${calcularTotal()}</h6>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={cerrarModal}>Cerrar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agregar Footer aquí */}
      <Footer />
    </div>
  );
}

export default App;
