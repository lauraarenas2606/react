import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import './ListaMensajes.css';

function ListaMensajes() {
    const [mensajes, setMensajes] = useState([]);
    const [mensajeEliminado, setMensajeEliminado] = useState(null);

    // Estados del formulario
    const [nombre, setNombre] = useState('');
    const [email, setEmail] = useState('');
    const [mensaje, setMensaje] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    // Obtener mensajes al cargar el componente
    useEffect(() => {
        const obtenerMensajes = async () => {
            try {
                const respuesta = await axios.get('http://3.84.108.84:5000/api/formulario');
                const mensajesOrdenados = respuesta.data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                setMensajes(mensajesOrdenados);
            } catch (error) {
                console.error('Error al obtener los mensajes:', error);
            }
        };

        obtenerMensajes();
    }, []);

    // Función para eliminar un mensaje
    const handleEliminarMensaje = async (mensajeId) => {
        try {
            await axios.delete(`http://3.84.108.84:5000/api/formulario/${mensajeId}`);
            setMensajeEliminado(mensajeId);
            setTimeout(() => {
                setMensajes(mensajes.filter((mensaje) => mensaje._id !== mensajeId));
                setMensajeEliminado(null);
            }, 300);
        } catch (error) {
            console.error('Error al eliminar el mensaje:', error);
        }
    };

    // Función para enviar el formulario
    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const respuesta = await axios.post('http://3.84.108.84:5000/api/formulario', {
                nombre,
                email,
                mensaje,
            });

            // Limpia el formulario
            setNombre('');
            setEmail('');
            setMensaje('');

            // Muestra un mensaje de éxito
            setSuccessMessage('Formulario enviado con éxito');

            // Agrega el nuevo mensaje a la lista sin duplicar
            setMensajes([respuesta.data, ...mensajes]);

            setTimeout(() => {
                setSuccessMessage('');
            }, 3000);
        } catch (error) {
            console.error('Error al enviar el formulario:', error);
        }
    };

    return (
        <div className="lista-mensajes">
            <h2 className="lista-mensajes__titulo">Mensajes Recibidos</h2>

            {/* Formulario para enviar mensaje */}
            <form onSubmit={handleSubmit}>
                <h3>Deja tu comentario</h3>
                <div>
                    <label htmlFor="nombre">Nombre:</label>
                    <input
                        type="text"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="mensaje">Mensaje:</label>
                    <textarea
                        id="mensaje"
                        value={mensaje}
                        onChange={(e) => setMensaje(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Enviar</button>
                {successMessage && <div>{successMessage}</div>}
            </form>

            {/* Lista de mensajes */}
            <div className="lista-mensajes__contenedor">
                {mensajes.map((mensaje) => (
                    <div
                        key={mensaje._id}
                        className={`lista-mensajes__card ${mensajeEliminado === mensaje._id ? 'lista-mensajes__card--eliminado' : ''}`}
                    >
                        <div className="lista-mensajes__card__header">
                            <img
                                className="lista-mensajes__card__avatar"
                                src="https://via.placeholder.com/50"
                                alt="Avatar"
                            />
                            <h3 className="lista-mensajes__card__nombre">{mensaje.nombre}</h3>
                            <button
                                className="lista-mensajes__card__eliminar"
                                onClick={() => handleEliminarMensaje(mensaje._id)}
                            >
                                <FontAwesomeIcon icon={faTrashAlt} />
                            </button>
                        </div>
                        <p className="lista-mensajes__card__email">{mensaje.email}</p>
                        <p className="lista-mensajes__card__mensaje">{mensaje.mensaje}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default ListaMensajes;
