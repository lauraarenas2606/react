import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import 'bootstrap/dist/css/bootstrap.min.css'; // Asegúrate de importar Bootstrap

function Navbar({ carrito, abrirModal }) {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
                <span className="navbar-brand">Mi Tienda</span>
                <div className="navbar__carrito d-flex align-items-center" onClick={abrirModal}>
                    <FontAwesomeIcon icon={faShoppingCart} size="lg" />
                    {carrito > 0 && (
                        <span className="badge bg-danger rounded-circle ms-2">{carrito}</span>
                    )}
                </div>
            </div>
        </nav>
    );
}

export default Navbar;
