import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ProductList.css';

function ProductList({ agregarAlCarrito }) {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        const obtenerProductos = async () => {
            try {
                const respuesta = await axios.get('http://3.84.108.84:5000/api/productos');
                setProductos(respuesta.data);
            } catch (error) {
                console.error('Error al obtener los productos:', error);
            }
        };

        obtenerProductos();
    }, []);

    // Función para manejar el botón de agregar al carrito
    const manejarAgregarAlCarrito = (producto) => {
        if (producto.cantidad > 0) {
            agregarAlCarrito(producto); // Pasando el producto completo
        }
    };

    return (
        <div className="product-list">
            <h1>Lista de Productos</h1>
            <div className="product-cards">
                {productos.map((producto) => (
                    <div className="product-card" key={producto._id}>
                        <img
                            src={producto.imagen || 'https://via.placeholder.com/150'}
                            alt={producto.nombre}
                            className="product-image"
                        />
                        <div className="product-details">
                            <h2 className="product-name">{producto.nombre}</h2>
                            <p className="product-price">${producto.precio}</p>
                            <p className="product-description">{producto.descripcion}</p>
                            <p className="product-quantity">
                                {producto.cantidad > 0 ? `Stock: ${producto.cantidad}` : 'Sin stock'}
                            </p>
                            <button
                                className="add-to-cart-btn"
                                onClick={() => manejarAgregarAlCarrito(producto)}
                                disabled={producto.cantidad === 0} // Deshabilita si no hay cantidad
                            >
                                {producto.cantidad > 0 ? 'Agregar al Carrito' : 'Agotado'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default ProductList;
